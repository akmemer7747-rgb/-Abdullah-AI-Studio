عبداللہ AI اسٹوڈیو — Android پروجیکٹ (ابتدائی ورژن)

اہم: یہ Android Studio project source ہے، تیار شدہ APK نہیں۔ اس ZIP میں APK پہلے سے compile نہیں کی گئی۔

اس ورژن میں:
1) YouTube oEmbed سے صرف عوامی عنوان حاصل ہوتا ہے۔
2) OpenAI API سے نئی، اصل Long یا Shorts اسکرپٹ بنتی ہے۔
3) Android کے اپنے Text-to-Speech سے انگریزی آواز کی فائل بنائی جا سکتی ہے۔ آواز/معیار فون کے TTS engine پر منحصر ہے۔
4) Pexels سے stock video کے لنکس تلاش کیے جاتے ہیں۔

ابھی شامل نہیں:
- خودکار مکمل MP4 montage/rendering
- AI thumbnail generation
- ویڈیو میں subtitles burn کرنا
یہ فیچرز اگلے ورژن میں شامل کرنے ہوں گے۔

APK بنانے کا طریقہ:
1. کمپیوٹر پر Android Studio انسٹال کریں۔
2. اس ZIP کو Extract کریں۔
3. Android Studio میں اس فولڈر کو Open کریں۔
4. Gradle sync مکمل ہونے دیں۔
5. Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
6. APK عام طور پر app/build/outputs/apk/debug/app-debug.apk میں ملے گی۔
7. APK اپنے Android فون میں منتقل کر کے انسٹال کریں۔

ضروری:
- OpenAI API key: https://platform.openai.com/api-keys
- Pexels API key: https://www.pexels.com/api/
- انٹرنیٹ ضروری ہے۔ API استعمال کرنے پر خرچ ہو سکتا ہے۔
- API keys کسی کے ساتھ شیئر نہ کریں۔ اس ابتدائی ورژن میں keys فون پر محفوظ نہیں کی جاتیں؛ ایپ بند ہونے پر دوبارہ درج کرنا ہوں گی۔

کاپی رائٹ:
YouTube لنک صرف موضوع/عنوان سمجھنے کے لیے ہے۔ ایپ دوسرے چینل کی ویڈیو، آڈیو یا captions ڈاؤن لوڈ/کاپی نہیں کرتی۔ اپنی اصل اسکرپٹ بنائیں اور صرف لائسنس یافتہ یا اجازت یافتہ stock footage استعمال کریں۔

موبائل سے Cloud Build کے ذریعے APK:
1. ZIP Extract کریں۔
2. Chrome میں github.com کھول کر اکاؤنٹ بنائیں/سائن اِن کریں۔
3. New repository بنائیں، نام Abdullah-AI-Studio رکھیں، Public منتخب کریں۔
4. Add file > Upload files میں Extract کیے ہوئے فولڈر کے اندر کی تمام فائلیں اور فولڈرز اپ لوڈ کریں۔ ZIP فائل خود اپ لوڈ نہ کریں۔
5. Commit changes کریں۔
6. Repository میں Actions ٹیب کھولیں، "Build Android APK" منتخب کریں، پھر Run workflow دبائیں۔
7. Build مکمل ہونے پر اسی run کے نیچے Artifacts میں Abdullah-AI-Studio-APK ڈاؤن لوڈ کریں۔
8. ZIP artifact Extract کریں؛ app-debug.apk انسٹال کریں۔ اگر Android اجازت مانگے تو Chrome/Files کے لیے Install unknown apps کی اجازت دیں۔

نوٹ: GitHub پر Public repository میں API keys، پاس ورڈ یا ذاتی معلومات شامل نہ کریں۔ اس سورس میں کوئی API key شامل نہیں۔
